# Interfaces pour le projet Amicus

Les interfaces du module interfaces.py sont utilisées dans le package amicus_bot et dans ses plugins.

# Interfaces for the Amicus project

The interfaces in the interfaces.py module are used in the amicus_bot package and its plugins.

